#machine_learning #algorithms #regression 

> **Elastic-net-регрессии** — вариант [[линейная регрессия|линейной регрессии]], использующий [[регуляризация|elastic-net-регуляризацию]].

В качестве ошибки используется сумма квадратов остатков + сумма коэффициентов.

$$\sum_{i=1}^n(y_i - \sum_j x_{ij}\beta_j)^2 + \lambda((1 - \alpha)\sum_{i=0}^N + \alpha \sum_{i=0}^N |\beta_i|)$$

где:
1) $\lambda$ — выбор между [[лассо-регрессия|лассо]] и [[ридж-регрессия|ридж]] регрессиями;
2) $\lambda = \infty$ — по мере увеличения силы регуляризации удаляется всё больше коэффициентов;
3) [[дилемма смещения-дисперсии|смещение]] увеличивается с увеличением $\lambda$;
4) [[дилемма смещения-дисперсии|дисперсия]] увеличивается с уменьшением $\lambda$.

### Как сделать в R

$0 < mixture < 1  \implies elastic-net\;regularisation$

```{r}
> elastic_net_reg <- linear_reg(penalty = 0.1, mixture = 0.5) %>%
+     set_engine("glmnet")
> 
> recipe_reg <- recipe(avg_glucose_level ~ ., original_data) %>%
+     step_normalize(all_numeric_predictors()) %>%
+     step_dummy(all_nominal_predictors())
> 
> pipeline <- workflow() %>%
+     add_recipe(recipe_reg) %>%
+     add_model(elastic_net_reg)
> 
> pipeline_fitted <- pipeline %>%
+     fit(original_data)
> 
> pipeline_fitted %>%
+     extract_fit_parsnip() %>%
+     tidy()
# A tibble: 17 x 3
   term                           estimate penalty
   <chr>                             <dbl>   <dbl>
 1 (Intercept)                 108.            0.1
 2 age                           8.72          0.1
 3 bmi                           0             0.1
 4 gender_Male                   4.11          0.1
 5 gender_Other                 45.6           0.1
 6 hypertension_X1              16.0           0.1
 7 heart_disease_X1             18.0           0.1
 8 ever_married_Yes              1.83          0.1
 9 work_type_Govt_job           -8.97          0.1
10 work_type_Never_worked       -1.76          0.1
11 work_type_Private            -7.51          0.1
12 work_type_Self.employed      -9.97          0.1
13 Residence_type_Urban         -0.569         0.1
14 smoking_status_never.smoked  -0.0000442     0.1
15 smoking_status_smokes        -0.360         0.1
16 smoking_status_Unknown       -2.59          0.1
17 stroke_X1                    12.7           0.1
```

---
[Ответ разработчиков tidymodels про параметр mixture](https://community.rstudio.com/t/tidymodels-code-for-ridge-lasso-and-elastic-net-using-glmnet/54343)