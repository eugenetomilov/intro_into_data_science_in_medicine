#machine_learning #quality_control #classification

> **Specifity (специфичность, FPR, false positive rate)** —  доля отрицательных объектов, которые правильно идентифицированы как отрицательные. Выражает способность модели обнаруживать отрицательные объекты.

$$Sensitivity = \frac{TN}{N} = \frac{TN}{TN + FP} = 1 - FPR$$

### Примеры
1) Сколько здоровых модель идентифицировала как здоровых?

#### Как сделать в R
[sensitivity()](https://yardstick.tidymodels.org/reference/sens.html)

```{r}
hpc_cv %>%
 filter(Resample == "Fold01") %>%
 sens(obs, pred)
#> # A tibble: 1 × 3
#>   .metric .estimator .estimate
#>   <chr>   <chr>          <dbl>
#> 1 sens    macro          0.548
```

#### Коэффициент ложноположительных результатов (false positive rate)

$$FPR = \frac{FP}{N} = \frac{FP}{FP + TN} = 1 - Specifity$$
___
![[Pasted image 20211129063041.png]]

[[макро-усреднение]], [[взвешенное макро-усреднение]], [[микро-усреднение]]

[Sensitivity and specificity explained: A Cochrane UK Trainees blog](https://uk.cochrane.org/news/sensitivity-and-specificity-explained-cochrane-uk-trainees-blog)