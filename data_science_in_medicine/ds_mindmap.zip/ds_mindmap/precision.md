#machine_learning #quality_control #classification

> **Precision (точность)** —  доля объектов, отнесённых классификатором к положительным и при этом действительно являющихся положительными. Выражает способность модели отличать данный класс от других классов.

$$Precision = \frac{TP}{TP + FP}$$

### Примеры
1) Сколько пациентов, определённых алгоритмом как больные, действительно являются больными?
![[Pasted image 20211129070021.png]]

#### Как сделать в R
[precision()](https://yardstick.tidymodels.org/reference/precision.html)

```{r}
hpc_cv %>%
 filter(Resample == "Fold01") %>%
 precision(obs, pred)
#> # A tibble: 1 × 3
#>   .metric   .estimator .estimate
#>   <chr>     <chr>          <dbl>
#> 1 precision macro          0.637
```
___
![[Pasted image 20211129063041.png]]

[[макро-усреднение]], [[взвешенное макро-усреднение]], [[микро-усреднение]]