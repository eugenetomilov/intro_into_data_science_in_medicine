#machine_learning #quality_control #classification

> **F1-measure (F1-мера)** —  [среднее гармоническое](https://ru.wikipedia.org/wiki/%D0%A1%D1%80%D0%B5%D0%B4%D0%BD%D0%B5%D0%B5_%D0%B3%D0%B0%D1%80%D0%BC%D0%BE%D0%BD%D0%B8%D1%87%D0%B5%D1%81%D0%BA%D0%BE%D0%B5) [[precision]] и [[recall]]. 

$$F_1 = \frac{2}{\frac{1}{Recall} + \frac{1}{Precision}} = 2 \cdot \frac{Recall \cdot Precision}{Recall + Precision} = \frac{TP}{TP + \frac{FP + FN}{2}}$$

В случае, если необходимо варьировать баланс между [[precision]] и [[recall]], используют $F_{\beta}$-меру. В то время, когда F1-мера оптимизирует одновременно recall и precision, $F_{\beta}$-мера позволяет выбирать, какая именно метрика предпочтительнее.

$$F_{\beta} = (\beta^2 + 1) \frac{Recall \cdot Precision}{Recall + \beta^2 Precision}$$

### Примеры
1) Данная метрика не имеет конкретной интерпретации, однако позволяет эффективно оптимизировать модель сразу по двум самым распространённым метрикам.

#### Как сделать в R
[f_meas()](https://yardstick.tidymodels.org/reference/f_meas.html)

```{r}
hpc_cv %>%
 filter(Resample == "Fold01") %>%
 f_meas(obs, pred)
#> # A tibble: 1 × 3
#>   .metric .estimator .estimate
#>   <chr>   <chr>          <dbl>
#> 1 f_meas  macro          0.563
```
___
![[Pasted image 20211129063041.png]]

[[макро-усреднение]], [[взвешенное макро-усреднение]], [[микро-усреднение]]