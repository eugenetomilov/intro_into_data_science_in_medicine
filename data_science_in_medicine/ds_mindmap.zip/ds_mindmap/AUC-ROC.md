#machine_learning #quality_control #classification

> **AUC-ROC** —  площадь под [[ROC-кривая|ROC-кривой]], основанной на [[sensitivity]] и [[specifity]]. Обычно используется там, где важно скорее упорядочивание объектов по вероятности принадлежности к классу, а не сам класс.

![[Pasted image 20211130020158.png]]

### Пояснения
1) **ROC** — receiver operating characteristic, кривая ошибок;
2) **AUC** — area under the curve, площадь под кривой.
3) Обычно значение метрики находится в интервале от 0.5 до 1, чем ближе к 1, тем лучше модель прогнозирует классы;
4) Если значение меньше 0.5, то это значит, что ответы модели можно инвертировать, возможно, неверно размечены классы (похоже на [[DOR (diagnostic odds ratio)]]);
5) Фактически, ROC-AUC — это доля пар объектов, которые модель [верно упорядочила](https://dyakonov.org/2017/07/28/auc-roc-%D0%BF%D0%BB%D0%BE%D1%89%D0%B0%D0%B4%D1%8C-%D0%BF%D0%BE%D0%B4-%D0%BA%D1%80%D0%B8%D0%B2%D0%BE%D0%B9-%D0%BE%D1%88%D0%B8%D0%B1%D0%BE%D0%BA/) по вероятностям принадлежности к положительному классу.

#### Как сделать в R
[roc_auc()](https://yardstick.tidymodels.org/reference/roc_auc.html)

```{r}
roc_auc(two_class_example, truth, Class1)
#> # A tibble: 1 × 3
#>   .metric .estimator .estimate
#>   <chr>   <chr>          <dbl>
#> 1 roc_auc binary         0.939
```
___
![[Pasted image 20211129063041.png]]

[[макро-усреднение]], [[взвешенное макро-усреднение]], [[микро-усреднение]]