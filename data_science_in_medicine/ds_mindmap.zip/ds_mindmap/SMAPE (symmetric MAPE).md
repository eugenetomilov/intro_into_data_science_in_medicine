#machine_learning #quality_control #regression

> **SMAPE (симметрическая средняя абсолютная ошибка в процентах)**

$$SMAPE = \frac{1}{N} \sum_{i=1}^N \frac{|y_i - f(x_i)|}{y_i + f(x_i)}$$

Данная модификация, в отличие от MAPE, имеет верхнюю границу в 100%.