#machine_learning #quality_control #classification

> **Sensitivity (чувствительность, TPR, true positive rate)** —  доля положительных объектов, которые модель правильно отнесла к положительным. Выражает способность модели обнаруживать положительные объекты. Аналогична [[recall]].

$$Sensitivity = \frac{TP}{P} = \frac{TP}{TP + FN} = 1 - FNR$$

### Примеры
1) Сколько больных модель идентифицировала как больных?

#### Как сделать в R
[sensitivity()](https://yardstick.tidymodels.org/reference/sens.html)

```{r}
hpc_cv %>%
 filter(Resample == "Fold01") %>%
 sens(obs, pred)
#> # A tibble: 1 × 3
#>   .metric .estimator .estimate
#>   <chr>   <chr>          <dbl>
#> 1 sens    macro          0.548
```

#### Коэффициент ложноотрицательных результатов (false negative rate)

$$FNR = \frac{FN}{P} = \frac{FN}{FN + TP} = 1 - Sensitivity$$
___
![[Pasted image 20211129063041.png]]

[[макро-усреднение]], [[взвешенное макро-усреднение]], [[микро-усреднение]]

[Sensitivity and specificity explained: A Cochrane UK Trainees blog](https://uk.cochrane.org/news/sensitivity-and-specificity-explained-cochrane-uk-trainees-blog)