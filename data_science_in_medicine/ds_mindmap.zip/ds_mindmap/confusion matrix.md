#machine_learning #quality_control #classification

> **Confusion matrix (матрица ошибок)** — матрица, в которой собрано количество верных ответов (**true positive**, **true negative**) и количество неверных ответов (**false positive**, **false negative**). Может быть создана как для бинарной [[классификация|классификации]] , так и для многоклассовой. Все [[функционал качества|формулы ошибок]] для классификации основываются на ней.

![[Pasted image 20211130012435.png]]

#### Примеры 
![[Pasted image 20211129062123.png]]
![[Pasted image 20211129062132.png]]
![[Pasted image 20211129062211.png]]
![[Pasted image 20211129062152.png]]

#### Как сделать в R
[conf_mat()](https://yardstick.tidymodels.org/reference/conf_mat.html)

```{r}
cm <- hpc_cv %>%
 filter(Resample == "Fold01") %>%
 conf_mat(obs, pred)
cm
#>           Truth
#> Prediction  VF   F   M   L
#>         VF 166  33   8   1
#>         F   11  71  24   7
#>         M    0   3   5   3
#>         L    0   1   4  10
```