#machine_learning #classification #quality_control 

> **Youden's J statistic (Индекс Йодена, информированность)** — метрика, объединяющая [[specifity]] и [[sensitivity]].

$$J = sensitivity + specifity - 1$$
$$J = \frac{TP}{TP + FN} + \frac{TN}{TN + FP} - 1$$

### Особенности
1) Имеет размах от 0 до 1;
2) Даёт нулевое занчение, когда тест бесполезен (возвращает одинаковую долю положительных и отрицательных результатов для групп больных и здоровых);
3) При отрицательных значениях может быть так, что метки перепутаны.

###  Как сделать в R

[j_index()](https://yardstick.tidymodels.org/reference/j_index.html)

```{r}
hpc_cv %>%
 filter(Resample == "Fold01") %>%
 j_index(obs, pred)
#> # A tibble: 1 × 3
#>   .metric .estimator .estimate
#>   <chr>   <chr>          <dbl>
#> 1 j_index macro          0.434
```