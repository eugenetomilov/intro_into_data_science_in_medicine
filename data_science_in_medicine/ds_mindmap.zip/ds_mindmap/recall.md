#machine_learning #quality_control #classification

> **Recall (полнота)** —  доля положительных объектов из числа всех положительных, которые классификатор нашёл. Выражает способность модели обнаруживать данный класс. Аналогична [[sensitivity]].

$$Recall = \frac{TP}{TP + FN}$$

### Примеры
1) Сколько больных удалось выявить из общего количества больных, которые присутствуют в выборке?
![[Pasted image 20211129070021.png]]

#### Как сделать в R
[recall()](https://yardstick.tidymodels.org/reference/recall.html)

```{r}
hpc_cv %>%
 filter(Resample == "Fold01") %>%
 recall(obs, pred)
#> # A tibble: 1 × 3
#>   .metric .estimator .estimate
#>   <chr>   <chr>          <dbl>
#> 1 recall  macro          0.548
```
___
![[Pasted image 20211129063041.png]]

[[макро-усреднение]], [[взвешенное макро-усреднение]], [[микро-усреднение]]